import Card from "./Card";

const projects = [
	{
		title: "Projet 1",
		description:
			"Lorem ipsum dolor sit amet consectetur adipisicing elit. Deserunt, doloribus?",
		image: "/public/images/chat_1.jpg",
	},
	{
		title: "Projet 2",
		description: "Lorem ipsum dolor sit amet consectetur adipisicing.",
		image: "/public/images/chat_2.jpg",
	},
	{
		title: "Projet 3",
		description:
			"Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente!",
		image: "/public/images/chat_3.webp",
	},
	{
		title: "Projet 4",
		description:
			"Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus, modi!",
		image: "/public/images/chat_4.jpg",
	},
	{
		title: "Projet 5",
		description: "Lorem ipsum dolor sit amet.",
		image: "/public/images/chat_5.jpg",
	},
	{
		title: "Projet 6",
		description:
			"Lorem ipsum dolor sit amet consectetur adipisicing elit. Deserunt, doloribus?",
		image: "/public/images/chat_6.jpg",
	},
];

export default function Gallery() {
	return (
		<section className="gallery--section">
			<div className="gallery--wrapper">
				{projects.map((project, index) => (
					<Card key={index} project={project} />
				))}
			</div>
		</section>
	);
}

export default function Header() {
	return (
		<header className="page--header">
			<div className="header--wrapper">
				<h1>Rémy Pierre</h1>
				<div className="header--user--wrapper">
					<a href="#">Login</a>
				</div>
			</div>
		</header>
	);
}
